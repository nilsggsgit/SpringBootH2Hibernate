insert into stores(store_id,address) values (101,'address1');
insert into stores(store_id,address) values (102,'address2');
insert into stores(store_id,address) values (103,'address3');

insert into stores_inventory (store_id,available_toys) values (101,10);
insert into stores_inventory (store_id,available_toys) values (102,20);
insert into stores_inventory (store_id,available_toys) values (103,30);