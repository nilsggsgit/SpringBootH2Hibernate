DROP TABLE IF EXISTS stores;

create table stores (
    store_id bigint identity,
    address varchar(1024) not null
);

DROP TABLE IF EXISTS stores_inventory;

create table stores_inventory (
    store_id bigint identity,
    available_toys bigint not null,
    FOREIGN KEY(store_id) REFERENCES stores(store_id)
);