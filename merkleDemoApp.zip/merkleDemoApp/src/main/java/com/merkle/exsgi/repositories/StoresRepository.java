package com.merkle.exsgi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.merkle.exsgi.entities.Stores;

public interface StoresRepository extends JpaRepository<Stores, String> {

}
