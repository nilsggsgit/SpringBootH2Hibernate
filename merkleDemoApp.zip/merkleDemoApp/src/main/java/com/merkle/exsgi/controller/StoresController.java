package com.merkle.exsgi.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.merkle.exsgi.entities.Stores;
import com.merkle.exsgi.entities.StoresInventory;
import com.merkle.exsgi.repositories.StoresInventoryRepository;
import com.merkle.exsgi.repositories.StoresRepository;

@RestController
public class StoresController {

	private static final Logger LOG = LoggerFactory.getLogger(StoresController.class);

	@Autowired
	private StoresInventoryRepository storesInventoryRepository;

	@Autowired
	private StoresRepository storesRepository;

	@GetMapping("/stores")
	public List<Stores> getAllStores() {
		LOG.info("Rest Controller fetch all stores");
		return storesRepository.findAll();
	}

	@GetMapping("/storesDetails")
	public List<StoresInventory> getStoresDetails() {
		LOG.info("Rest Controller fetch all Stores Details");
		return storesInventoryRepository.findAll();
	}

	

}
