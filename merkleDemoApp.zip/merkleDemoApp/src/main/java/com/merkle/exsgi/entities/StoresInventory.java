package com.merkle.exsgi.entities;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "stores_inventory")
public class StoresInventory implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name = "STORE_ID")
	private int storeId;
	
	@Column(name = "AVAILABLE_TOYS")
	private int availableToys;
	
	@OneToOne(cascade = CascadeType.ALL)
    @JoinColumn(name = "STORE_ID", referencedColumnName = "STORE_ID")
    private Stores stores;
 
}
