package com.merkle.exsgi.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.merkle.exsgi.entities.StoresInventory;

public interface StoresInventoryRepository extends JpaRepository<StoresInventory, String> {

}
