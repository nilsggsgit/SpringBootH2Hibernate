package com.merkle.exsgi.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "STORES")
public class Stores implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@Column(name="STORE_ID")
	private int storeId;
	
	@Column(name="ADDRESS")
	private String address;
	

}
